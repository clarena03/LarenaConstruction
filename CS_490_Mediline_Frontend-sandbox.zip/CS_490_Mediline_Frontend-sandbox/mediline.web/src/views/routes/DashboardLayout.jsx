import { useContext } from 'react';
import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import Topbar, { TopbarItem } from '../../components/Dashboard/Topbar';
import BaseIcon from '../../components/General/BaseIcon';
import Container, { ItemGroup } from '../../components/General/Container';
import DropdownMenu from '../../components/General/DropdownMenu';
import { UserContext } from '../../context/UserProvider';
import { dashboardLayoutViewModel } from '../../viewModels/DashboardLayoutViewModel';

function DashboardLayout() {
    const { logout, currentUser } = useContext(UserContext);
    const navigate = useNavigate();
    const location = useLocation();

    let basePath = null;

    if (currentUser.role !== 'pharmacy') {
        basePath = `/dashboard/${currentUser.role}`;
    }
    else {
        basePath = `/dashboard/pharmacist`;
    }

    const pathNames = {
        appointment: `${basePath}/appointment`,
        profile: `${basePath}/profile`,
        discussion: `${basePath}/discussion-forum`,
    };

    const handleLogout = () => {
        logout();
        navigate(`/`);
    }

   //console.log(`User: ${currentUser.firstName} ${currentUser.lastName}, Role: ${currentUser.role}`);

    return (
        <>
            <Container
                fitScreen={true}
                customClass="bg-secondary-500 align-items-center justify-content-center p-10"
                content={[
                    <>
                        <Container
                            customClass="bg-secondary-500 br-md box-shadow p-0 position-relative"
                            style={{
                                minHeight: "90vh",
                                minWidth: "90vw",
                                zIndex: "0"
                            }}
                            fitParent={true}
                            content={[
                                <>
                                    <Container
                                        customClass="bg-neutral-1100 box-shadow-sm br-top-md position-absolute"
                                        style={{
                                            height: "120px",
                                            width: "100%",
                                            zIndex: "1"
                                        }}
                                    />
                                    <ItemGroup
                                        fitParent={true}
                                        stretch={true}
                                        axis={false}
                                        items={[
                                            <>
                                                <ItemGroup
                                                    customClass="p-10 gradient-dark br-md gap-8 align-content-center"
                                                    style={{
                                                        zIndex: "2"
                                                    }}
                                                    axis={true}
                                                    fitParent={true}
                                                    items={[
                                                        <>
                                                            <div></div>
                                                            <Container
                                                                key="home"
                                                                customClass={`nav-item ${location.pathname === basePath ? "active" : ""}`}
                                                                style={{
                                                                    height: "55px",
                                                                    width: "55px",
                                                                }}
                                                                isClickable={true}
                                                                onClick={() => {
                                                                    navigate(`${basePath}`);
                                                                }}
                                                                content={[
                                                                    <>
                                                                        <BaseIcon width={30} height={30} fillColor="#E3E3E3">
                                                                            <rect x="2" y="2" width="9" height="11" rx="2">
                                                                            </rect>
                                                                            <rect x="13" y="2" width="9" height="7" rx="2">
                                                                            </rect>
                                                                            <rect x="2" y="15" width="9" height="7" rx="2">
                                                                            </rect>
                                                                            <rect x="13" y="11" width="9" height="11" rx="2">
                                                                            </rect>
                                                                        </BaseIcon>
                                                                    </>
                                                                ]}
                                                            />
                                                            <Container
                                                                customClass={`nav-item ${location.pathname === pathNames.profile ? " active" : ""}`}
                                                                style={{
                                                                    height: "55px",
                                                                    width: "55px"
                                                                }}
                                                                isClickable={true}
                                                                onClick={() => {
                                                                    navigate(`${pathNames.profile}`);
                                                                }}
                                                                content={[
                                                                    <>
                                                                        <BaseIcon width={30} height={28} fillColor="#E3E3E3" viewBox="-32 0 512 512">
                                                                            <path d="M224 256c70.7 0 128-57.3 128-128S294.7 0 224 0 96 57.3 96 128s57.3 128 128 128zm89.6 32h-16.7c-22.2 10.2-46.9 16-72.9 16s-50.6-5.8-72.9-16h-16.7C60.2 288 0 348.2 0 422.4V464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48v-41.6c0-74.2-60.2-134.4-134.4-134.4z" />
                                                                        </BaseIcon>
                                                                    </>
                                                                ]}
                                                            />
                                                            {currentUser.role !== 'pharmacy' && (
                                                                <Container
                                                                    key="discussion"
                                                                    customClass={`nav-item ${location.pathname === pathNames.discussion ? " active" : ""}`}
                                                                    isClickable={true}
                                                                    onClick={() => {
                                                                        navigate(`${pathNames.discussion}`);
                                                                    }}
                                                                    style={{
                                                                        height: "55px",
                                                                        width: "55px"
                                                                    }}
                                                                    content={[
                                                                        <>
                                                                            <BaseIcon width={28.5} height={22} fillColor="#E3E3E3" viewBox="0 0 512 512">
                                                                                <path class="st0" d="M432.469,0.01H79.531C35.61,0.01,0,35.62,0,79.541v0.232l219.118,199.838
                                                                                             c10.505,9.572,23.592,14.271,36.872,14.29c13.301-0.02,26.368-4.718,36.873-14.29L512,79.773v-0.232
                                                                                             C512,35.62,476.389,0.01,432.469,0.01z"/>
                                                                                <path class="st0" d="M255.99,353.55c-27.532,0.019-55.279-10-77.064-29.863L0,160.508v271.951c0,43.92,35.61,79.531,79.531,79.531
                                                                                             h352.938c43.92,0,79.531-35.611,79.531-79.531V160.508L333.056,323.687C311.289,343.55,283.543,353.568,255.99,353.55z"/>
                                                                            </BaseIcon>
                                                                        </>
                                                                    ]}
                                                                />
                                                            )}
                                                            <div></div>
                                                        </>
                                                    ]}
                                                />
                                                <ItemGroup
                                                    axis={true}
                                                    fitParent={true}
                                                    style={{
                                                        minWidth: "80vw",
                                                        gridAutoRows: "auto 1fr",
                                                    }}
                                                    items={[
                                                        <>
                                                            <ItemGroup
                                                                customClass="gap-3 pl-10 pr-12 py-8 align-items-center justify-content-space-between"
                                                                fitParent={true}
                                                                stretch={true}
                                                                axis={false}
                                                                style={{
                                                                    zIndex: "2"
                                                                }}
                                                                items={[
                                                                    <>
                                                                        <ItemGroup
                                                                            customClass="gap-3"
                                                                            stretch={true}
                                                                            axis={false}
                                                                            items={[
                                                                                <>
                                                                                    <BaseIcon
                                                                                        height="50px"
                                                                                        width="50px"
                                                                                        fillColor="none">
                                                                                        <>
                                                                                            <g id="SVGRepo_bgCarrier" stroke-width="0" />
                                                                                            <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round" />
                                                                                            <g id="SVGRepo_iconCarrier">
                                                                                                <path d="M12.2407 2.96432C12.0063 2.96432 11.797 3.07184 11.6595 3.24024L11.6024 3.28346C9.45801 2.63339 7.03194 3.15091 5.33598 4.83602C3.82743 6.33492 3.24863 8.40778 3.59957 10.3471L3.58455 10.3619L2.6274 11.3129C1.7951 12.1399 1.7951 13.4807 2.6274 14.3077C3.11636 14.7935 3.78381 14.9939 4.42002 14.9089C4.51377 15.2552 4.6974 15.5824 4.9709 15.8542C5.34265 16.2235 5.81755 16.4279 6.30347 16.4673C6.34307 16.9503 6.54878 17.4223 6.92061 17.7917C7.30952 18.1781 7.81134 18.384 8.32054 18.4093C8.34607 18.9151 8.55325 19.4136 8.94208 19.7999C9.70236 20.5554 10.8942 20.6207 11.7291 19.996L12.1156 20.3801C12.952 21.2111 14.3079 21.2111 15.1443 20.3801C15.5147 20.012 15.721 19.5428 15.7633 19.0621C16.2462 19.021 16.7177 18.8168 17.0874 18.4495C17.4581 18.0812 17.6636 17.6114 17.7043 17.1303C18.1809 17.0858 18.6453 16.8821 19.0104 16.5193C19.2966 16.235 19.4844 15.89 19.5738 15.526C20.2005 15.6003 20.854 15.3986 21.3349 14.9208C22.1672 14.0938 22.1672 12.753 21.3349 11.926L20.5014 11.0979L20.6727 10.4313C21.045 8.98208 20.8578 7.44693 20.1482 6.12848C19.1007 4.182 17.0615 2.96933 14.8448 2.96933L13.2381 2.96933C13.1696 2.96601 13.1008 2.96432 13.0316 2.96432H12.2407ZM15.1649 7.90945L18.6286 11.351L18.6325 11.3551L18.6458 11.3687L20.2708 12.9833C20.5155 13.2264 20.5155 13.6205 20.2708 13.8635C20.0262 14.1066 19.6296 14.1066 19.3849 13.8635L17.7599 12.2489C17.4661 11.9569 16.9897 11.9569 16.6959 12.2489L16.6796 12.2651C16.3857 12.557 16.3857 13.0304 16.6796 13.3223L17.9464 14.581C18.1912 14.8243 18.1912 15.2188 17.9464 15.4621C17.7232 15.6838 17.3724 15.7037 17.1274 15.5206C16.8267 15.2958 16.4051 15.3263 16.1403 15.592C15.8756 15.8577 15.8491 16.2769 16.0784 16.5734C16.2668 16.8171 16.2481 17.1689 16.0234 17.3922C15.7968 17.6173 15.4389 17.6344 15.1934 17.4424C14.8947 17.2087 14.4674 17.2332 14.1977 17.4995C13.9279 17.7658 13.9006 18.1902 14.1339 18.4885C14.3276 18.7361 14.3093 19.0952 14.0802 19.3228C13.8315 19.5699 13.4284 19.5699 13.1797 19.3228L12.808 18.9535L12.9132 18.8489C13.7455 18.0219 13.7455 16.6811 12.9132 15.8542C12.5243 15.4677 12.0225 15.2619 11.5133 15.2366C11.4878 14.7308 11.2806 14.2323 10.8918 13.8459C10.52 13.4766 10.0451 13.2722 9.55922 13.2328C9.51962 12.7499 9.3139 12.2779 8.94208 11.9084C8.45311 11.4226 7.78567 11.2222 7.14945 11.3072C7.0557 10.9609 6.87208 10.6337 6.59857 10.3619C6.16723 9.93332 5.597 9.72685 5.03184 9.7425C4.88504 8.36976 5.34111 6.94543 6.40004 5.89327C7.38426 4.91535 8.69207 4.45489 9.98101 4.5119L8.48356 5.64643C7.45969 6.42216 7.26245 7.87941 8.04327 8.89941C8.82232 9.91708 10.2805 10.1144 11.302 9.34048L13.1908 7.90945H15.1649ZM9.3894 6.84203L12.5277 4.46432H13.0316C13.0811 4.46432 13.1302 4.46565 13.1789 4.46826C13.1922 4.46898 13.2056 4.46933 13.219 4.46933H14.8448C16.513 4.46933 18.043 5.38193 18.8274 6.83933C19.3221 7.7586 19.4773 8.8178 19.2712 9.83451L16.0591 6.63806C15.9178 6.49195 15.7232 6.40945 15.52 6.40945L12.9388 6.40945C12.7752 6.40945 12.6162 6.4629 12.4858 6.56165L10.3962 8.14487C10.0326 8.42032 9.5116 8.3498 9.23434 7.98762C8.95886 7.62776 9.02817 7.11571 9.3894 6.84203ZM6.03496 14.7969C5.86706 14.6301 5.81439 14.3921 5.87697 14.1807C5.90557 14.084 5.95823 13.9929 6.03496 13.9167L6.99212 12.9657C7.23675 12.7226 7.63338 12.7226 7.87802 12.9657C8.11986 13.2059 8.12262 13.5938 7.8863 13.8375L7.87776 13.8459L6.92061 14.797L6.91236 14.8052C6.8374 14.877 6.74888 14.9265 6.65519 14.9539C6.44237 15.0161 6.20287 14.9637 6.03496 14.7969ZM5.54368 11.4285C5.61917 11.5066 5.67014 11.5995 5.69659 11.6976C5.75261 11.9054 5.6986 12.1364 5.53451 12.2994L4.57736 13.2504C4.33272 13.4935 3.93609 13.4935 3.69146 13.2504C3.44682 13.0073 3.44682 12.6133 3.69146 12.3702L4.64861 11.4192C4.89325 11.1761 5.28988 11.1761 5.53451 11.4192L5.54368 11.4285ZM10.892 18.7427C10.8152 18.8191 10.7233 18.8714 10.6258 18.8998C10.4132 18.9618 10.1739 18.9094 10.0061 18.7427C9.83837 18.576 9.78565 18.3383 9.84799 18.1269C9.87655 18.0301 9.92926 17.9388 10.0061 17.8625L10.9633 16.9114C11.2079 16.6683 11.6046 16.6683 11.8492 16.9114C12.0938 17.1545 12.0938 17.5486 11.8492 17.7917L10.892 18.7427ZM8.87057 16.7345C8.7939 16.8106 8.7023 16.8629 8.60513 16.8914C8.39225 16.9537 8.15263 16.9013 7.98467 16.7345C7.8167 16.5676 7.76406 16.3295 7.82675 16.118C7.85432 16.0249 7.9042 15.937 7.97639 15.8626L7.98492 15.8542L8.94208 14.9031L8.95032 14.8949C9.19556 14.6602 9.5859 14.6629 9.82772 14.9032C10.0724 15.1463 10.0724 15.5404 9.82772 15.7834L8.87057 16.7345Z" fill="hsl(200, 30%, 25%)" />
                                                                                            </g>
                                                                                        </>
                                                                                    </BaseIcon>
                                                                                    <div className="font-7 text-neutral-1100">
                                                                                        <h1 className="font-medium text-dark-200">MEDILINE</h1>
                                                                                    </div>
                                                                                </>
                                                                            ]}
                                                                        />
                                                                        <ItemGroup
                                                                            customClass="align-items-center gap-5"
                                                                            axis={false}
                                                                            stretch={false}
                                                                            items={[
                                                                                <>
                                                                                    {/*
                                                                                <BaseIcon
                                                                                    height="20px"
                                                                                    width="20px"
                                                                                    viewBox="0 0 16 16"
                                                                                    fillColor="none">
                                                                                    <>
                                                                                        <path d="M3 5C3 2.23858 5.23858 0 8 0C10.7614 0 13 2.23858 13 5V8L15 10V12H1V10L3 8V5Z" fill="#000000" />
                                                                                        <path d="M7.99999 16C6.69378 16 5.58254 15.1652 5.1707 14H10.8293C10.4175 15.1652 9.30621 16 7.99999 16Z" fill="#000000" />
                                                                                    </>
                                                                                </BaseIcon>
                                                                                */}
                                                                                    <DropdownMenu
                                                                                        offsetY={10}
                                                                                        offsetX={-10}
                                                                                        triggerLabel={[
                                                                                            <BaseIcon
                                                                                                height="50px"
                                                                                                width="50px"
                                                                                                fillColor='none'
                                                                                                viewBox='0 0 61.7998 61.7998'>
                                                                                                <circle cx="30.8999" cy="30.8999" fill="hsl(210, 50%, 90%)" r="30.8999" />
                                                                                                <path d="M23.255 38.68l15.907.121v12.918l-15.907-.121V38.68z" fill="hsl(210, 10%, 95%)" fill-rule="evenodd" />
                                                                                                <path d="M43.971 58.905a30.967 30.967 0 0 1-25.843.14V48.417H43.97z" fill="hsl(210, 50%, 90%)" fill-rule="evenodd" />
                                                                                                <path d="M33.403 61.7q-1.238.099-2.503.1-.955 0-1.895-.057l1.03-8.988h2.41z" fill="hsl(210, 40%, 70%)" fill-rule="evenodd" />
                                                                                                <path d="M25.657 61.332A34.072 34.072 0 0 1 15.9 57.92a31.033 31.033 0 0 1-7.857-6.225l1.284-3.1 13.925-6.212c0 5.212 1.711 13.482 2.405 18.95z" fill="hsl(210, 40%, 95%)" fill-rule="evenodd" />
                                                                                                <path d="M39.165 38.759v3.231c-4.732 5.527-13.773 4.745-15.8-3.412z" fill-rule="evenodd" opacity="0.11" />
                                                                                                <path d="M31.129 8.432c21.281 0 12.987 35.266 0 35.266-12.267 0-21.281-35.266 0-35.266z" fill="hsl(210, 10%, 95%)" fill-rule="evenodd" />
                                                                                                <path d="M18.365 24.046c-3.07 1.339-.46 7.686 1.472 7.658a31.972 31.972 0 0 1-1.472-7.659z" fill="hsl(210, 10%, 95%)" fill-rule="evenodd" />
                                                                                                <path d="M44.14 24.045c3.07 1.339.46 7.687-1.471 7.658a31.993 31.993 0 0 0 1.471-7.658z" fill="hsl(210, 10%, 95%)" fill-rule="evenodd" />
                                                                                                <path d="M21.931 14.328c-3.334 3.458-2.161 13.03-2.161 13.03l-1.05-.495c-6.554-25.394 31.634-25.395 25.043 0l-1.05.495s1.174-9.572-2.16-13.03c-4.119 3.995-14.526 3.974-18.622 0z" fill="hsl(210, 30%, 70%)" fill-rule="evenodd" />
                                                                                                <path d="M36.767 61.243a30.863 30.863 0 0 0 17.408-10.018l-1.09-2.631-13.924-6.212c0 5.212-1.7 13.393-2.394 18.861z" fill="hsl(210, 40%, 95%)" fill-rule="evenodd" />
                                                                                                <path d="M39.162 41.98l-7.926 6.465 6.573 5.913s1.752-9.704 1.353-12.378z" fill="hsl(210, 50%, 90%)" fill-rule="evenodd" />
                                                                                                <path d="M23.253 41.98l7.989 6.465-6.645 5.913s-1.746-9.704-1.344-12.378z" fill="hsl(210, 50%, 90%)" fill-rule="evenodd" />
                                                                                                <path d="M28.109 51.227l3.137-2.818 3.137 2.818-3.137 2.817-3.137-2.817z" fill="hsl(210, 40%, 70%)" fill-rule="evenodd" />
                                                                                                <path d="M25.767 61.373a30.815 30.815 0 0 1-3.779-.88 2.652 2.652 0 0 1-.114-.093l-3.535-6.39 4.541-3.26h-4.752l1.017-6.851 4.11-2.599c.178 7.37 1.759 15.656 2.512 20.073z" fill="hsl(210, 40%, 93%)" fill-rule="evenodd" />
                                                                                                <path d="M36.645 61.266c.588-.098 1.17-.234 1.747-.384.682-.177 1.36-.377 2.034-.579l.134-.043 3.511-6.315-4.541-3.242h4.752l-1.017-6.817-4.11-2.586c-.178 7.332-1.758 15.571-2.51 19.966z" fill="hsl(210, 40%, 93%)" fill-rule="evenodd" />
                                                                                            </BaseIcon>
                                                                                        ]}
                                                                                        menuItems={[
                                                                                            <ItemGroup
                                                                                                axis={false}
                                                                                                stretch={true}
                                                                                                isClickable={true}
                                                                                                onClick={handleLogout}
                                                                                                items={[
                                                                                                    <>
                                                                                                        <p>Logout</p>
                                                                                                    </>
                                                                                                ]}
                                                                                            />
                                                                                        ]}
                                                                                    />
                                                                                </>
                                                                            ]}
                                                                        />
                                                                    </>
                                                                ]}
                                                            />
                                                            <Container
                                                                customClass="p-0"
                                                                fitParent={true}
                                                                content={[
                                                                    <Outlet />
                                                                ]}
                                                            />
                                                        </>
                                                    ]}
                                                />
                                            </>
                                        ]}
                                    />
                                </>
                            ]}
                        />
                    </>
                ]}
            />
        </>
    );
}

export default DashboardLayout;